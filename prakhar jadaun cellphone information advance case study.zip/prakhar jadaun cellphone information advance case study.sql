--SQL Advance Case Study


--Q1--BEGIN 
SELECT DISTINCT STATE
FROM DIM_LOCATION L
JOIN FACT_TRANSACTIONS FT ON L.IDLocation = FT.IDLocation
JOIN DIM_DATE D ON FT.Date=D.DATE
WHERE D.YEAR>=2005





--Q1--END

--Q2--BEGIN
	
SELECT TOP 1 L.State
FROM DIM_LOCATION L
JOIN FACT_TRANSACTIONS FT ON L.IDLocation=FT.IDLocation
JOIN DIM_MODEL M ON FT.IDModel=M.IDModel
JOIN DIM_MANUFACTURER DM ON M.IDManufacturer=DM.IDManufacturer
WHERE DM.Manufacturer_Name='Samsung'
GROUP BY L.State
ORDER BY COUNT(*)DESC









--Q2--END

--Q3--BEGIN      
	SELECT M.model_Name,L.ZipCode,L.State,COUNT(*)AS Transaction_Count
	FROM FACT_TRANSACTIONS FT
	JOIN DIM_MODEL M ON FT.IDModel=M.IDModel
	JOIN DIM_LOCATION L ON FT.IDLocation=L.IDLocation
	GROUP BY M.Model_Name,L.ZipCode,L.State









--Q3--END

--Q4--BEGIN
SELECT TOP 1 M.model_Name,M.Unit_price
FROM DIM_MODEL M
ORDER BY M.Unit_price






--Q4--END

--Q5--BEGIN
SELECT Model_Name, manufacturer_name, AVG(Unit_price) AS Avg_unit_price FROM DIM_MODEL AS Model
INNER JOIN DIM_MANUFACTURER AS Mnf
ON model.IDManufacturer=Mnf.IDManufacturer
WHERE Manufacturer_Name IN(
SELECT TOP 5 Manufacturer_Name FROM FACT_TRANSACTIONS AS T
JOIN DIM_MODEL AS MOD
ON MOD.IDModel=T.IDModel
JOIN DIM_MANUFACTURER AS Mnf
ON MOD.IDManufacturer=Mnf.IDManufacturer
GROUP BY Manufacturer_Name
ORDER BY SUM(quantity) DESC)
GROUP BY Model_Name,Manufacturer_Name
ORDER BY Avg_unit_price DESC













--Q5--END

--Q6--BEGIN
SELECT C.Customer_name,AVG(FT.TotalPrice) AS Average_Amount_Spent
FROM DIM_CUSTOMER C
JOIN FACT_TRANSACTIONS FT ON C.IDCustomer=FT.IDCustomer
JOIN DIM_DATE D ON FT.Date=D.DATE
WHERE D.YEAR=2009
GROUP BY C.Customer_name
HAVING AVG(FT.TotalPrice)>500












--Q6--END
	
--Q7--BEGIN  
SELECT M.model_Name
FROM DIM_MODEL M
JOIN FACT_TRANSACTIONS FT ON M.IDModel=FT.IDModel
JOIN DIM_DATE D ON FT.Date=D.DATE
WHERE D.YEAR IN (2008,2009,2010)
GROUP BY M.Model_Name
HAVING COUNT(DISTINCT D.YEAR)=3
ORDER BY SUM(FT.Quantity)DESC
OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY

	
















--Q7--END	
--Q8--BEGIN
SELECT *FROM(SELECT*FROM(
SELECT Manufacturer_Name,totalSales,YEAR,
ROW_NUMBER() OVER(ORDER BY totalSales DESC) AS _rank
FROM(SELECT MF.Manufacturer_Name,D.YEAR,
SUM(T.TotalPrice) AS totalSales
FROM DIM_MANUFACTURER AS MF
JOIN DIM_MODEL AS MDL
ON MF.IDManufacturer=MDL.IDManufacturer
JOIN FACT_TRANSACTIONS AS T
ON MDL.IDModel=T.IDModel
JOIN DIM_DATE AS D
ON T.Date=D.DATE
WHERE D.YEAR=2009
GROUP BY MF.Manufacturer_Name,D.YEAR)AS table1) AS table2
WHERE _rank=2
UNION
SELECT*FROM(
SELECT Manufacturer_Name,totalSales,YEAR,
ROW_NUMBER() OVER(ORDER BY totalSales DESC) AS _rank
FROM(SELECT MF.Manufacturer_Name,D.YEAR,
SUM(T.TotalPrice) AS totalSales
FROM DIM_MANUFACTURER AS MF
JOIN DIM_MODEL AS MDL
ON MF.IDManufacturer=MDL.IDManufacturer
JOIN FACT_TRANSACTIONS AS T
ON MDL.IDModel=T.IDModel
JOIN DIM_DATE AS D
ON T.Date=D.DATE
WHERE D.YEAR=2010
GROUP BY MF.Manufacturer_Name,D.YEAR)AS table3) AS table4
WHERE _rank=2)
AS mainTable

















--Q8--END
--Q9--BEGIN
SELECT DISTINCT DM.Manufacturer_Name
FROM DIM_MANUFACTURER DM
JOIN DIM_MODEL M ON DM.IDManufacturer=M.IDManufacturer
JOIN FACT_TRANSACTIONS FT ON M.IDModel=FT.IDModel
JOIN DIM_DATE D ON FT.DATE=D.DATE
WHERE D.YEAR=2010
AND DM.Manufacturer_Name NOT IN(
SELECT DISTINCT DM.Manufacturer_Name
FROM DIM_MANUFACTURER DM
JOIN DIM_MODEL M ON DM.IDManufacturer=M.IDManufacturer
JOIN FACT_TRANSACTIONS FT ON M.IDModel=FT.IDModel
JOIN DIM_DATE D ON FT.Date=D.DATE
WHERE D.YEAR=2009)

















--Q9--END

--Q10--BEGIN
SELECT TOP 100
 CustomerName,
 Order_Year,
 Avg_Spend,
 Avg_Quantity,
 LAG(Avg_Spend)OVER(PARTITION BY CustomerName ORDER BY Order_Year) AS Prev_Avg_Spend,
 ((Avg_Spend - LAG(Avg_Spend)OVER(PARTITION BY CustomerName ORDER BY Order_Year))/
 LAG(Avg_Spend)OVER(PARTITION BY CustomerName ORDER BY Order_Year))*100 AS
 Change_Spend_Percentage
 FROM(
    SELECT
	   C.Customer_Name AS CustomerName,
	   YEAR(T.Date)AS Order_Year,
	   AVG(T.TotalPrice)AS Avg_spend,
	   AVG(T.Quantity)AS Avg_Quantity
FROM
  DIM_CUSTOMER C
JOIN
  FACT_TRANSACTIONS T ON C.IDCustomer=T.IDCustomer
GROUP BY
  C.Customer_Name,YEAR(T.Date)
)AS CustomerYearlyStats
ORDER BY
  Avg_Spend DESC

















--Q10--END
	